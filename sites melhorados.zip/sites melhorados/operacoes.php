<?php
$a = 10;
$b = 5;
$soma = $a + $b;
?><!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><title>Operações</title>
<style>
body{font-family:sans-serif;background:#f0f8ff;padding:40px;}
.card{background:white;padding:20px;border-radius:12px;box-shadow:0 0 12px #0002;}
</style>
</head>
<body>
<div class="card">
<?php echo "A soma de $a e $b é $soma."; ?>
</div>
</body>
</html>