<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Hello PHP</title>
    <style>
        body {
            background: #121212;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #00eaff;
            font-family: Verdana, sans-serif;
            font-size: 32px;
        }
    </style>
</head>
<body>

<?php
echo "Hello, World!";
?>

</body>
</html>